export const RELEASE = Object.freeze({
  product: "Portfolio Dashboard Pro",
  version: "2.0 RC1",
  build: "2026.08.02-rc1",
  designSystem: "2.0.3",
  schema: 1,
});

export const CHANGELOG = Object.freeze([
  {
    version: "2.0 RC1",
    date: "2026-08-02",
    title: "Release Candidate",
    items: [
      "Pridėtas System Info ir Diagnostics centras.",
      "Pridėtas konfigūracijos atsarginės kopijos eksportas.",
      "Maršrutai kraunami pagal poreikį su React.lazy.",
      "Pridėta bendra klaidų gaudyklė ir RC būsenos indikatoriai.",
      "Suvienodinta produkto versijos informacija.",
    ],
  },
  {
    version: "1.9",
    date: "2026-08-02",
    title: "AI ir ataskaitos",
    items: ["AI Insights v1.0", "Report Center v1.0", "Search Center v1.0"],
  },
  {
    version: "1.8",
    date: "2026-08-02",
    title: "Design System",
    items: ["Design System v2.0.3", "Motion & Polish", "Bendri UI komponentai"],
  },
  {
    version: "1.7",
    date: "2026-08-02",
    title: "Multi Portfolio ir Sync",
    items: ["Evaldas, Rima, Gerda ir Šeima", "Sync Center v1.1", "Vienas atnaujinimo BAT"],
  },
]);
